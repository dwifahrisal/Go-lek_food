const userData = [
    {
        name: 'Anonymous',
        email: 'example@email.com',
        address: 'not defined',
        password: 'password',
        photo: 'https://picsum.photos/300/200',
        signed: false
    }
];

export default userData;