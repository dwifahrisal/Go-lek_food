const apiBaseURL = 'http://34.101.68.137:8000/';

export default apiBaseURL;